#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <linux/bpf.h>
#include <bpf/bpf.h>
#include <bpf/libbpf.h>

#define BPF_OBJ_FILE "fifo_scheduler.bpf.o"

int main(int argc, char **argv) {
  struct bpf_object *obj;
  int prog_fd;
  int err;

  // Load BPF object
  err = bpf_prog_load(BPF_OBJ_FILE, BPF_PROG_TYPE_SCHED_EXT, &obj, &prog_fd);
  if (err) {
    fprintf(stderr, "Failed to load BPF object: %s\n", strerror(errno));
    return 1;
  }

  // Attach scheduler to CPU 0
  err = bpf_prog_attach(prog_fd, 0, BPF_SCHED_CLS_EXT, 0);
  if (err) {
    fprintf(stderr, "Failed to attach BPF program: %s\n", strerror(errno));
    return 1;
  }

  printf("FIFO scheduler loaded and attached to CPU 0\n");

  // Keep the program running
  while (1) {
    sleep(1);
  }

  return 0;
}