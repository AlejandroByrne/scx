#include <linux/bpf.h>
#include <bpf/bpf_helpers.h>

struct sched_entity {
  u64 exec_start; // Timestamp when the task started execution
};

// Define the BPF map to store task information
struct {
  __uint(type, BPF_MAP_TYPE_PERCPU_ARRAY);
  __uint(key_size, sizeof(u32));
  __uint(value_size, sizeof(struct sched_entity));
  __uint(max_entries, 1);
} task_info SEC(".maps");

// Called when a task is enqueued
SEC("sched_ext_enqueue")
int handle_enqueue(struct sched_entity *se) {
  u32 key = 0;
  struct sched_entity *entity = bpf_map_lookup_elem(&task_info, &key);
  if (!entity) {
    // First task, store its start time
    entity = bpf_map_lookup_elem(&task_info, &key);
    entity->exec_start = bpf_ktime_get_ns();
  }
  return 0;
}

// Called when a task is dequeued
SEC("sched_ext_dequeue")
int handle_dequeue(struct sched_entity *se) {
  return 0;
}

// Called when the scheduler needs to pick the next task
SEC("sched_ext_pick_next")
int handle_pick_next(struct sched_entity *se) {
  u32 key = 0;
  struct sched_entity *entity = bpf_map_lookup_elem(&task_info, &key);
  if (entity) {
    // Return the first task
    return 0;
  }
  // No tasks available
  return -1;
}

char LICENSE[] SEC("license") = "GPL";